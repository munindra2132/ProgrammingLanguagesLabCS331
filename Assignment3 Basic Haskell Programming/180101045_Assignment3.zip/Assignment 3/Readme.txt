/*
* CS331 Programming Language Lab
* Assignment 3 : Basic Haskell Programming
* 
* Student Details -
* Name - Munindra Naik
* Roll - 180101045
*
*
* Instructions to execute -
* 1) On terminal Type "ghc -o A A.hs" and hit enter
* 2) After successful compilation type "./A" and the program will execute
* 3) Each file contains test cases which will get executed and printed on the screen after the previous command
* 4) Then the user can enter user specific input
* 5) the result will be printed on the terminal
*/