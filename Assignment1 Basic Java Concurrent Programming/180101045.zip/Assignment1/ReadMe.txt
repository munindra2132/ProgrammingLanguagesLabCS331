CS331 Programming Language Lab
Assignment 1 Basic Java Concurrent Programming

Name - Munindra Naik
Roll - 180101045

Files Contained - 
1) A.java ( For part A)
2) B.java ( For part B)
3) C.java ( For part C)

To execute the java files -
1) On linux terminal type "javac filename.java" say for A.java we would type
"javac A.java" similarly for other files  "javac B.java" for B.java and "javac C.java" for C.java
2) Then after successful compilation type "java filename" say for A.java we
would type "java A", similarly for other files "java B" for B.java and "java C" for C.java 
3) After that we would prompter to enter number of threads and hit enter
